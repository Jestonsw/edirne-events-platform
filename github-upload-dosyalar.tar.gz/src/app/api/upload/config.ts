export const config = {
  api: {
    bodyParser: {
      sizeLimit: '10mb',
    },
  },
}